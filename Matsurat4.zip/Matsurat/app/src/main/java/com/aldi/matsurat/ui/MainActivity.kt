package com.aldi.matsurat.ui

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.aldi.matsurat.data.local.UserPreferences
import com.aldi.matsurat.data.response.ResponseLogin
import com.aldi.matsurat.databinding.ActivityMainBinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mb = ActivityMainBinding.inflate(layoutInflater)
        setContentView(mb.root)

        auth = Firebase.auth

        mb.cardMorning.setOnClickListener {
            val  intent = Intent(this, MorningActivity::class.java)
            intent.putExtra(MorningActivity.MODE, "morning")
            startActivity(intent)
        }

        mb.cardEvening.setOnClickListener {
            val  intent = Intent(this, MorningActivity::class.java)
            intent.putExtra(MorningActivity.MODE, "evening")
            startActivity(intent)
        }

        mb.btnLogout.setOnClickListener {
            val database = UserPreferences(this)
            val user = ResponseLogin()
            user.username = null
            user.password = null
            database.setUser(user)


            // menambahkan sign out
            auth.signOut()

            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        mb.tvUsername.text = UserPreferences(this).getUser().username
    }
}